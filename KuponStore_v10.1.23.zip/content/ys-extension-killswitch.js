/**
 * Eklenti chrome://extensions üzerinden kapatılınca Yemeksepeti oturumunu düşürür.
 * MV3'te background anında ölür; orphan content script document.cookie ile temizler.
 * /logout çağrılmaz — sunucudaki token bozulmaz. Ödeme sonrası sekme gezinmesi bunu tetiklemez.
 */
(function ysExtensionKillSwitch() {
  if (window.top !== window) return;
  var host = (window.location.hostname || "").toLowerCase();
  if (host.indexOf("yemeksepeti.com") === -1) return;

  var HOME_URL = "https://www.yemeksepeti.com/";
  var deadStreak = 0;
  var triggered = false;
  var timer = null;

  function extAlive() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  function clearClientStorage() {
    try { window.localStorage.clear(); } catch (e) {}
    try { window.sessionStorage.clear(); } catch (e) {}
    try {
      var hostname = window.location.hostname;
      var domains = [hostname, "." + hostname];
      var parts = hostname.split(".");
      if (parts.length > 2) {
        var parent = parts.slice(parts.length - 2).join(".");
        domains.push(parent, "." + parent);
      }
      var past = "Thu, 01 Jan 1970 00:00:00 GMT";
      var cookies = document.cookie ? document.cookie.split(";") : [];
      for (var i = 0; i < cookies.length; i++) {
        var eq = cookies[i].indexOf("=");
        var name = (eq > -1 ? cookies[i].substr(0, eq) : cookies[i]).trim();
        if (!name) continue;
        document.cookie = name + "=; expires=" + past + "; path=/;";
        for (var d = 0; d < domains.length; d++) {
          document.cookie = name + "=; expires=" + past + "; path=/; domain=" + domains[d] + ";";
          document.cookie = name + "=; expires=" + past + "; path=/; domain=" + domains[d] + "; Secure; SameSite=None";
        }
      }
    } catch (e) {}
  }

  function showLockOverlay() {
    try {
      if (document.getElementById("ys-ext-kill-overlay")) return;
      var ov = document.createElement("div");
      ov.id = "ys-ext-kill-overlay";
      ov.style.cssText = "position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;" +
        "background:rgba(8,8,8,0.97);z-index:2147483647;display:flex;flex-direction:column;" +
        "align-items:center;justify-content:center;color:#fff;text-align:center;padding:24px;" +
        "font-family:Arial,Helvetica,sans-serif;cursor:not-allowed;";
      ov.innerHTML =
        "<div style=\"max-width:460px;\">" +
        "<div style=\"font-size:46px;margin-bottom:16px;\">&#128274;</div>" +
        "<h2 style=\"font-size:24px;margin:0 0 12px;font-weight:700;\">Eklenti kapatıldı</h2>" +
        "<p style=\"font-size:16px;line-height:1.6;opacity:.9;margin:0;\">Oturum kapatılıyor...</p></div>";
      (document.body || document.documentElement).appendChild(ov);
      ov.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); }, true);
      ov.addEventListener("contextmenu", function (e) { e.preventDefault(); }, true);
    } catch (e) {}
  }

  function killSession() {
    if (triggered) return;
    triggered = true;
    if (timer) { try { clearInterval(timer); } catch (e) {} }
    showLockOverlay();
    clearClientStorage();
    try { window.location.replace(HOME_URL); }
    catch (e) { try { window.location.href = HOME_URL; } catch (e2) {} }
  }

  function checkNow() {
    if (triggered) return;
    if (!extAlive()) killSession();
  }

  timer = setInterval(function () {
    if (triggered) return;
    if (extAlive()) { deadStreak = 0; return; }
    deadStreak++;
    if (deadStreak >= 2) killSession();
  }, 1000);

  try {
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "visible") checkNow();
    }, true);
    window.addEventListener("focus", checkNow, true);
    window.addEventListener("pageshow", checkNow, true);
    window.addEventListener("pointerdown", checkNow, true);
    window.addEventListener("keydown", checkNow, true);
  } catch (e) {}
})();
