/**
 * Uygulama yönlendirme katmanı gizlenmez.
 * Metinle yukarı yürüyüp kabuğu kapatmak ana ekranı siyah bırakıyordu.
 */
(function () {
  "use strict";
  if (window.__ksYsAppBanner) return;
  window.__ksYsAppBanner = true;

  function skipRoleScreen() {
    if (window.__ksYsRoleDone || !document.body) return;
    var text = document.body.innerText || document.body.textContent || "";
    if (text.indexOf("rolünüzü seçin") === -1 && text.indexOf("rolunuzu secin") === -1) return;
    if (text.indexOf("Restoran sahibi") === -1 && text.indexOf("Kurye") === -1) return;
    var nodes = document.body.querySelectorAll("button, a, [role='button'], span, div, p");
    for (var i = 0; i < nodes.length; i++) {
      var label = (nodes[i].innerText || nodes[i].textContent || "").replace(/\s+/g, " ").trim();
      if (label !== "Atla") continue;
      if ((nodes[i].innerText || "").length > 12) continue;
      window.__ksYsRoleDone = true;
      var target = nodes[i].closest ? (nodes[i].closest("button, a, [role='button']") || nodes[i]) : nodes[i];
      try { target.click(); } catch (e) {}
      return;
    }
  }

  var queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    setTimeout(function () {
      queued = false;
      skipRoleScreen();
    }, 60);
  }

  skipRoleScreen();
  try {
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e2) {}
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { skipRoleScreen(); }, { once: true });
  }
})();
