/**
 * Hesap ve ödeme sayfasında telefon numarasını gizler.
 * Hesap formunda değer durur, ekranda görünmez. Kart alanlarına dokunulmaz.
 */
(function () {
  "use strict";
  if (window.__ksYsAccountPhone) return;
  window.__ksYsAccountPhone = true;

  function pageKind() {
    var path = String((location && location.pathname) || "");
    if (/\/account(\/|$)/i.test(path)) return "account";
    if (/\/checkout(\/|$)/i.test(path)) return "checkout";
    return "";
  }

  function looksLikePhone(value) {
    var t = String(value || "").trim();
    if (!t || t.length > 24 || /[a-zA-Z]/.test(t)) return false;
    if (!/^\+?[\d\s\-()]+$/.test(t)) return false;
    var digits = t.replace(/\D/g, "");
    return digits.length >= 10 && digits.length <= 15;
  }

  function mask(el) {
    if (!el || el.getAttribute("data-ks-phone-mask") === "1") return;
    el.setAttribute("data-ks-phone-mask", "1");
    el.style.setProperty("-webkit-text-security", "disc", "important");
    el.style.setProperty("color", "transparent", "important");
    el.style.setProperty("text-shadow", "none", "important");
    el.style.setProperty("caret-color", "transparent", "important");
    try {
      el.setAttribute("autocomplete", "off");
    } catch (e) {}
  }

  function isPhoneField(el) {
    var hint = [
      el.getAttribute("type"),
      el.getAttribute("name"),
      el.getAttribute("id"),
      el.getAttribute("autocomplete"),
      el.getAttribute("placeholder"),
      el.getAttribute("aria-label"),
    ]
      .join(" ")
      .toLowerCase();
    return (
      el.getAttribute("type") === "tel" ||
      /phone|telefon|mobile|gsm|tel\b/.test(hint)
    );
  }

  function scrub() {
    var kind = pageKind();
    if (!kind || !document.body) return;
    var inputs = document.querySelectorAll("input, textarea");
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      if (kind === "checkout" && !isPhoneField(input)) continue;
      if (looksLikePhone(input.value) || (kind === "checkout" && isPhoneField(input))) mask(input);
    }
    var nodes = document.querySelectorAll("p, span, div, dd, li, label");
    for (var n = 0; n < nodes.length; n++) {
      var el = nodes[n];
      if (el.childElementCount > 0) continue;
      if (!looksLikePhone(el.textContent)) continue;
      el.textContent = "";
    }
    try {
      var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
      var doomed = [];
      var textNode;
      while ((textNode = walker.nextNode())) {
        if (looksLikePhone(textNode.nodeValue)) doomed.push(textNode);
      }
      for (var d = 0; d < doomed.length; d++) doomed[d].nodeValue = "";
    } catch (e) {}
  }

  function boot() {
    scrub();
    try {
      new MutationObserver(scrub).observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
      });
    } catch (e) {}
    setInterval(scrub, 800);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
