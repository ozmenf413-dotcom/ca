/**
 * KuponStore — Yemeksepeti Siparişlerim
 * order_history yanıtını dönüştürür: eski gerçek siparişleri gizler,
 * token'a sabit fake sipariş ekler; giriş sonrası gerçek siparişler korunur.
 */
(function () {
  "use strict";
  if (window.__ksYsOrdersLoaded) return;
  window.__ksYsOrdersLoaded = true;

  function isOrderHistoryEndpoint(url) {
    return typeof url === "string" && url.indexOf("/api/v5/orders/order_history") !== -1;
  }

  function readOrdersCutoffTs() {
    try {
      var v = document.documentElement.getAttribute("data-ys-orders-cutoff");
      var n = v ? parseInt(v, 10) : 0;
      return n && n > 0 ? n : 0;
    } catch (e) {
      return 0;
    }
  }

  function waitForOrdersCutoff() {
    var found = readOrdersCutoffTs();
    if (found) return Promise.resolve(found);
    return new Promise(function (resolve) {
      var start = Date.now();
      var timer = setInterval(function () {
        var n = readOrdersCutoffTs();
        if (n || Date.now() - start > 1500) {
          clearInterval(timer);
          resolve(n || Date.now());
        }
      }, 40);
    });
  }

  function getUrlOffset(url) {
    try {
      var m = /[?&]offset=(\d+)/.exec(url || "");
      return m ? parseInt(m[1], 10) : 0;
    } catch (e) {
      return 0;
    }
  }

  function orderedAtToTs(item) {
    try {
      var d = item && item.ordered_at && item.ordered_at.date;
      if (!d) return 0;
      return new Date(String(d).replace(" ", "T")).getTime() || 0;
    } catch (e) {
      return 0;
    }
  }

  function isActiveOrder(item) {
    try {
      var sf = item && item.status_flags;
      if (sf && sf.is_active === true) return true;
      if (sf && sf.is_past_order === false && sf.is_completed !== true && sf.is_canceled !== true)
        return true;
      var cs = item && item.current_status;
      if (cs && cs.type && String(cs.type).toLowerCase() !== "final") return true;
      return false;
    } catch (e) {
      return false;
    }
  }

  function _pad2(n) {
    return (n < 10 ? "0" : "") + n;
  }
  function _fmtDate(ts) {
    var d = new Date(ts);
    return (
      d.getFullYear() +
      "-" +
      _pad2(d.getMonth() + 1) +
      "-" +
      _pad2(d.getDate()) +
      " " +
      _pad2(d.getHours()) +
      ":" +
      _pad2(d.getMinutes()) +
      ":" +
      _pad2(d.getSeconds())
    );
  }

  var FAKE_ORDER_POOL = [
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2025-02-18 12:51:07","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000011,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"gn2k-x2g5","ordered_at":{"date":"2025-02-18 12:30:57","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2025-02-18 12:51:07","timezone":"Europe/Istanbul"},"total_value":160,"subtotal":310,"vendor":{"id":0,"code":"gn2k","name":"Dillere Destan Ev Yemekleri","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":37.042823,"longitude":35.299904,"primary_cuisine_id":1067,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/gn2k-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Etli Kuru Fasulye Menü","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Etli Kuru Fasulye Menü","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Bulgur Pilavı, cacık","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":180,"placeholders":null},"total_price":180,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false},{"name":"Zeytinyağlı Sarma","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Zeytinyağlı Sarma","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":130,"placeholders":null},"total_price":130,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2025-02-18 12:51:07","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":160}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2024-01-06 21:03:39","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000012,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"jj9k-hhhn","ordered_at":{"date":"2024-01-06 20:47:30","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2024-01-06 21:03:39","timezone":"Europe/Istanbul"},"total_value":62,"subtotal":162,"vendor":{"id":0,"code":"jj9k","name":"Zater Döner","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":37.743712,"longitude":29.09579257,"primary_cuisine_id":1064,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/jj9k-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Patates Kızartması","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Patates Kızartması","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":40,"placeholders":null},"total_price":40,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false},{"name":"XL Zater Tavuk Döner Dürüm","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"XL Zater Tavuk Döner Dürüm","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Çift Lavaş","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Yanına ekstra mayonez koyarsanız sevinirim. Ekstra lavasli olacak","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":122,"placeholders":null},"total_price":122,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2024-01-06 21:03:39","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":62}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2025-05-25 16:45:55","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"h9wt-jjxt","ordered_at":{"date":"2025-05-25 15:59:34","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2025-05-25 16:45:55","timezone":"Europe/Istanbul"},"total_value":178.59,"subtotal":356,"vendor":{"id":0,"code":"h9wt","name":"Öz Anteplioğlu Pide & Lahmacun & Dürüm","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":41.086517,"longitude":28.896555,"primary_cuisine_id":1080,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/h9wt-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Su (50 cl.)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Su (50 cl.)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":2,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":36,"placeholders":null},"total_price":36,"quantity":2,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false},{"name":"Lahmacun","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Lahmacun","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":2,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Acılı","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":128,"placeholders":null},"total_price":128,"quantity":2,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false},{"name":"Lahmacun","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Lahmacun","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":3,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Acısız","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":192,"placeholders":null},"total_price":192,"quantity":3,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2025-05-25 16:45:55","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":178.59}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2025-03-02 23:51:36","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"d3hu-jvxg","ordered_at":{"date":"2025-03-02 23:36:49","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2025-03-02 23:51:36","timezone":"Europe/Istanbul"},"total_value":160,"subtotal":335,"vendor":{"id":0,"code":"d3hu","name":"Komagene Etsiz Çiğ Köfte","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":37.8612551,"longitude":32.5335752,"primary_cuisine_id":1061,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/ce6mj-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"%50 Kampanyalı Çiğ Köfte (600 g + 300 g)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"%50 Kampanyalı Çiğ Köfte (600 g + 300 g)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Çiğ Köfte (600 gr.) (çok acılı), Çok Acı Sos (18 gr.), Çok Acı Sos (18 gr.), Çiğ Köfte Sos (18 gr.), İstemiyorum","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":335,"placeholders":null},"total_price":335,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2025-03-02 23:51:36","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":160}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":false,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_VD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2024-01-21 20:07:39","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"enk6-g0z8","ordered_at":{"date":"2024-01-21 17:06:58","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2024-01-21 17:36:39","timezone":"Europe/Istanbul"},"total_value":150,"subtotal":250,"vendor":{"id":0,"code":"enk6","name":"Şahin Kebap","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":38.394415,"longitude":27.009139,"primary_cuisine_id":1071,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/enk6-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"İskender (Et Dönerden)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"İskender (Et Dönerden)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":250,"placeholders":null},"total_price":250,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2024-01-21 17:36:39","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":150}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"vendor","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_VD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2025-05-27 20:00:21","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"cw12-1dwa","ordered_at":{"date":"2025-05-27 16:58:19","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2025-05-27 17:28:18","timezone":"Europe/Istanbul"},"total_value":300,"subtotal":450,"vendor":{"id":0,"code":"cw12","name":"Gaziantepli Bozoğlu Baklava & Börek","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":36.86976,"longitude":30.735112,"primary_cuisine_id":1086,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/cw12-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Fıstıklı Kadayıf (500 gr.)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Fıstıklı Kadayıf (500 gr.)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":450,"placeholders":null},"total_price":450,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2025-05-27 17:28:18","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":300}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"vendor","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2024-02-03 16:30:13","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"u1kt-5u5s","ordered_at":{"date":"2024-02-03 15:51:33","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2024-02-03 16:30:13","timezone":"Europe/Istanbul"},"total_value":50,"subtotal":170,"vendor":{"id":0,"code":"u1kt","name":"Köfteci Yusuf","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":41.0072663,"longitude":28.7958602,"primary_cuisine_id":1073,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/ck5yy-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Soğan Halkası (3 Adet)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Soğan Halkası (3 Adet)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":10,"placeholders":null},"total_price":10,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false},{"name":"Köfteci Yusuf Acılı Parmak Sucuk (Fermente) (500 gr.)","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Köfteci Yusuf Acılı Parmak Sucuk (Fermente) (500 gr.)","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":160,"placeholders":null},"total_price":160,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2024-02-03 16:30:13","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":50}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_VD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2025-03-07 21:23:05","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"uvln-2510-sudx","ordered_at":{"date":"2025-03-07 18:22:12","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2025-03-07 18:51:02","timezone":"Europe/Istanbul"},"total_value":160,"subtotal":335,"vendor":{"id":0,"code":"uvln","name":"En Trendy Pizza","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":37.169225,"longitude":28.380262,"primary_cuisine_id":1082,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/uvln-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Izgara Sporcu Tavuk","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Izgara Sporcu Tavuk","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":null,"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":335,"placeholders":null},"total_price":335,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2025-03-07 18:51:02","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":160}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"vendor","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null},
    {"current_status":{"code":16,"message":"RESTAURANTS_OTP_OD_PROGRESS_DELIVERED","type":"final","changedAt":{"date":"2024-01-09 17:37:21","timezone":"Europe/Istanbul"},"internal_status_code":"621 - "},"order_address":"Merkez Mah., Ataturk Cad., 5, 34000 Istanbul","delivery_address":{"id":100000010,"city":"Istanbul","address_line_1":"Ataturk Cad.","address_line_2":"5","address_line_3":"Merkez Mah.","address_line_4":"Istanbul","address_line_5":"","address_other":"","room":"","flat_number":"","structure":"","building":"","floor":"","district":"","postcode":"34000","company":"","latitude":41.0082,"longitude":28.9784,"delivery_instructions":""},"order_id":0,"order_code":"bms4-umc5","ordered_at":{"date":"2024-01-09 17:20:01","timezone":"Europe/Istanbul"},"confirmed_delivery_time":{"date":"2024-01-09 17:37:21","timezone":"Europe/Istanbul"},"total_value":55,"subtotal":155,"vendor":{"id":0,"code":"bms4","name":"Dürümle","logo":"","service_tax_percentage_amount":0,"service_fee_percentage_amount":0,"vat_percentage_amount":0,"is_service_fee_enabled":false,"is_service_tax_visible":false,"is_service_tax_enabled":false,"is_vat_visible":false,"is_vat_disabled":false,"address":"","latitude":37.7820313,"longitude":30.5450488,"primary_cuisine_id":1071,"metadata":{"timezone":"Europe/Istanbul"},"city_id":0,"vertical":"restaurants","customer_contact_phone_number":"+902120000000","hero_listing_image":"https://images.deliveryhero.io/image/fd-tr/LH/cn4bs-listing.jpg"},"voucher":{"voucher":"","expirationDate":1790542799000,"type":"amount","value":150,"description":""},"order_products":[{"name":"Soslu Tavuk Dürümle","name_attributes":{"style":"highlight","text_color":"neutral_primary","value":"Soslu Tavuk Dürümle","placeholders":null},"quantity_attributes":{"style":"highlight","text_color":"neutral_primary","value":1,"placeholders":null},"toppings_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"Dürümle Sos (Adet), soslu tavuk dürüm, soğan istemiyorum","placeholders":null},"special_instructions_attributes":{"style":"body_sm","text_color":"neutral_secondary","value":"","placeholders":null},"subtitle_attributes":null,"price_attributes":{"style":"body","text_color":"neutral_primary","value":155,"placeholders":null},"total_price":155,"quantity":1,"sold_out":false,"tag":null,"status":"available","weight_attributes":null,"replacement_products":[],"replacement_attributes":null,"is_meal_for_one":false}],"sms_verification_needed":false,"order_already_rated":true,"has_been_reported_late":false,"rider_tip":0,"charity":0,"service_fee_total":0,"difference_to_minimum":0,"difference_to_minimum_with_vat":0,"expedition_type":"delivery","server_time":{"date":"2024-01-09 17:37:21","timezone":"Europe/Istanbul"},"payment_type_code":"yemekpay_creditcard","payment":{"breakdown":[{"code":"yemekpay_creditcard","group":"online_payment","translation_key":"OTP_PAID_WITH_ONLINE_PAYMENT","amount":55}]},"delivery_features":{"show_map":false,"display_map":false,"show_cart":false,"show_statuses":false,"show_vendor_contact":false,"show_vendor_delivery_time":false,"show_rider_chat":false,"show_payment_breakdown":false,"show_help_button":false},"delivery_provider":"own_delivery_foodpanda","is_cancellable":false,"status_flags":{"is_paid":true,"is_active":false,"is_picked_up":false,"is_delivered":true,"is_canceled":false,"is_preorder":false,"is_preorder_active":false,"is_past_order":true,"is_completed":true,"is_reorderable":true,"is_reorderable_after_cancellation":false,"is_rateable":false,"is_meal_for_one":false},"dynamic_fees":[],"loyalty":null,"status_messages":{"titles":[]},"status_history":[],"payment_refunds":[],"rider_tip_eligible":false,"reminder":null}
  ];

  function _deepClone(o) {
    try {
      return JSON.parse(JSON.stringify(o));
    } catch (e) {
      return o;
    }
  }

  function _getOrdersSeed() {
    try {
      var v = document.documentElement.getAttribute("data-ys-orders-seed");
      var n = v ? parseInt(v, 10) : 0;
      return n && n > 0 ? n : 0;
    } catch (e) {
      return 0;
    }
  }

  function buildFakeOrders(baseTs) {
    var n = FAKE_ORDER_POOL.length;
    if (n === 0) return [];
    var seed = _getOrdersSeed();
    var index = ((seed % n) + n) % n;
    var f = _deepClone(FAKE_ORDER_POOL[index]);
    var ts = baseTs - 24 * 60 * 60 * 1000;
    if (f.ordered_at) f.ordered_at.date = _fmtDate(ts);
    if (f.confirmed_delivery_time) f.confirmed_delivery_time.date = _fmtDate(ts + 30 * 60 * 1000);
    if (f.current_status && f.current_status.changedAt)
      f.current_status.changedAt.date = _fmtDate(ts + 35 * 60 * 1000);
    return [f];
  }

  function _ordersPayload(items) {
    return JSON.stringify({
      status_code: 200,
      data: { total_count: String(items.length), items: items, features: {} },
    });
  }

  function transformOrderHistory(realText, cutoffTs, offset) {
    if (offset && offset > 0) {
      try {
        var j = JSON.parse(realText);
        if (j && j.data) {
          j.data.items = [];
          j.data.total_count = "0";
          return JSON.stringify(j);
        }
      } catch (e) {}
      return _ordersPayload([]);
    }
    var json = null;
    try {
      json = JSON.parse(realText);
    } catch (e) {
      json = null;
    }
    var kept = [];
    if (json && json.data && Array.isArray(json.data.items)) {
      for (var i = 0; i < json.data.items.length; i++) {
        var it = json.data.items[i];
        var ts = orderedAtToTs(it);
        if (isActiveOrder(it) || (ts && ts >= cutoffTs - 120000)) kept.push(it);
      }
    }
    var finalItems = kept.concat(buildFakeOrders(cutoffTs));
    if (json && json.data) {
      json.data.items = finalItems;
      json.data.total_count = String(finalItems.length);
      return JSON.stringify(json);
    }
    return _ordersPayload(finalItems);
  }

  function mockXhr(xhr, status, body) {
    try {
      Object.defineProperty(xhr, "readyState", { value: 4, configurable: true });
      Object.defineProperty(xhr, "status", { value: status, configurable: true });
      Object.defineProperty(xhr, "statusText", {
        value: status === 200 ? "OK" : "ERR",
        configurable: true,
      });
      Object.defineProperty(xhr, "response", { value: body, configurable: true });
      Object.defineProperty(xhr, "responseText", { value: body, configurable: true });
    } catch (e) {}
  }

  var _origOpen = XMLHttpRequest.prototype.open;
  var _origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this._ksYsOhUrl = typeof url === "string" ? url : "";
    this._ksYsOhMethod = method;
    return _origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    var self = this;
    if (isOrderHistoryEndpoint(this._ksYsOhUrl)) {
      var url = this._ksYsOhUrl;
      var headers = {};
      try {
        // Best-effort: browser will still send cookies via credentials
      } catch (e) {}
      (async function () {
        var cutoff = await waitForOrdersCutoff();
        var out;
        try {
          var resp = await fetch(url, { method: "GET", credentials: "include", headers: headers });
          var realText = await resp.text();
          out = transformOrderHistory(realText, cutoff, getUrlOffset(url));
        } catch (e) {
          out = _ordersPayload(buildFakeOrders(cutoff));
        }
        mockXhr(self, 200, out);
        try {
          if (typeof self.onreadystatechange === "function") self.onreadystatechange();
          if (typeof self.onload === "function") self.onload();
          if (typeof self.onloadend === "function") self.onloadend();
          self.dispatchEvent(new Event("readystatechange"));
          self.dispatchEvent(new Event("load"));
          self.dispatchEvent(new Event("loadend"));
        } catch (e2) {}
      })();
      return;
    }
    return _origSend.apply(this, arguments);
  };

  var _origFetch = window.fetch;
  window.fetch = async function (resource, init) {
    var url = resource instanceof Request ? resource.url : String(resource || "");
    if (isOrderHistoryEndpoint(url)) {
      try {
        var resp = await _origFetch.apply(this, arguments);
        var text = await resp.text();
        var cutoff = await waitForOrdersCutoff();
        var out = transformOrderHistory(text, cutoff, getUrlOffset(url));
        return new Response(out, {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      } catch (e) {
        return new Response(_ordersPayload(buildFakeOrders(readOrdersCutoffTs() || Date.now())), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      }
    }
    return _origFetch.apply(this, arguments);
  };

  console.log("[KuponStore] YS Siparişlerim koruması aktif");
})();
